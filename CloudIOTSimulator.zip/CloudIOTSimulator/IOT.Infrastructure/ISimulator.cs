﻿using IOT.Models;
using System.Collections.Generic;

namespace IOT.Infrastructure
{
    public interface ISimulator
    {
        void Send(IEnumerable<IotTemparatureModel> temparatureLists);
        IEnumerable<IotTemparatureModel> Receive(string folderPath);
    }
}
