﻿using IOT.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IOT.Infrastructure
{
    public interface IDatabaseManager
    {
        Task InsertAsync(IEnumerable<IotTemparatureModel> iotTemparatures);
    }
}
