﻿using IOT.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using System.Data;
using System.Threading.Tasks;
using IOT.Infrastructure;
using System;

namespace IOT.DataAccess
{
    public class DatabaseManager: IDatabaseManager
    {
        private readonly string _connectionString;
        public DatabaseManager(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task InsertAsync(IEnumerable<IotTemparatureModel> iotTemparatures)
        {
            try
            {
                string processQuery = "INSERT INTO DeviceMonitorInfo VALUES (@DeviceId, @Temparature,@Humidity, @RecordedTime)";
                using (IDbConnection con = new SqlConnection(_connectionString))
                {
                    await con.ExecuteAsync(processQuery, iotTemparatures);
                }
            }
            catch(Exception ex)
            {
                throw new OperationCanceledException(ex.Message);
            }
        }
    }
}
