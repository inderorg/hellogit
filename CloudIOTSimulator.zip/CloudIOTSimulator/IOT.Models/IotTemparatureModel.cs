﻿using System;

namespace IOT.Models
{
    public class IotTemparatureModel
    {
        public string DeviceId { get; set; }
        public string Temparature { get; set; }
        public string Humidity { get; set; }
        public DateTime RecordedTime { get; set; }
    }
}
