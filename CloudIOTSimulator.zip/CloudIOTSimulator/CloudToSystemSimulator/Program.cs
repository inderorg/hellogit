﻿using IOT.Core;
using IOT.DataAccess;
using System;
using System.Linq;

namespace CloudToSystemSimulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reading the data from Cloud to system.");

            var simulator = new Simulator();
            var dabaseManager = new DatabaseManager("server=localhost;database=myDb;uid=myUser;password=myPass;");

            var temparatureData = simulator.Receive(@"C:\IOT_Example\device_to_cloud_data\");
            Console.WriteLine("Reading the data from Cloud to system is completed.");
            Console.WriteLine("Inserting the data into sql table has been started.!!!");
            dabaseManager.InsertAsync(temparatureData).GetAwaiter().GetResult();

            Console.WriteLine($"Inserting the data:{temparatureData.Count()} into sql table has been completed.!!!");
        }
    }
}
