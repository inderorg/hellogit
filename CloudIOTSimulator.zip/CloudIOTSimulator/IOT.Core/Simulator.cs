﻿using IOT.Infrastructure;
using IOT.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace IOT.Core
{
    public class Simulator: ISimulator
    {
        public void Send(IEnumerable<IotTemparatureModel> temparatureLists)
        {
            var serializedData = JsonConvert.SerializeObject(temparatureLists);

            string filePath = $@"C:\IOT_Example\device_to_cloud_data\device_temp_{DateTime.UtcNow.ToString("yyyy-MM-dd-HH-mm-ss")}.json";

            File.WriteAllText(filePath, serializedData);
        }

        public IEnumerable<IotTemparatureModel> Receive(string folderPath)
        {
            var devicedataList = new List<IotTemparatureModel>();
            var filesInFolder = GetFiles(folderPath);

            foreach(var file in filesInFolder)
            {
                using (StreamReader r = new StreamReader(file))
                {
                    string data = r.ReadToEnd();
                    devicedataList.AddRange(JsonConvert.DeserializeObject<List<IotTemparatureModel>>(data));
                }
                File.Delete(file);
            }

            return devicedataList;
        }

        private static string[] GetFiles(string folderPath)
        {
           return Directory.GetFiles(folderPath, "*.json");
        }
    }
}
