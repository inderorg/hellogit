﻿using IOT.Core;
using IOT.Models;
using System;
using System.Collections.Generic;
using System.Threading;

namespace DeviceToCloudSimulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserting data for Device to Cloud.!!!");

            var deviceList = new List<string> { "Device-I", "Device-II", "Device-III", "Device-IV" };
            var temparatureLists = new List<IotTemparatureModel>();

            double minTemperature = 20;
            double minHumidity = 60;
            Random rand = new Random();

            var simulator = new Simulator();

            foreach(var device in deviceList)
            {
                Console.WriteLine($"Inserting data for the device:{device}.");
                temparatureLists.Add(new IotTemparatureModel
                {
                    DeviceId = device,
                    Temparature = (minTemperature + rand.NextDouble() * 15).ToString(),
                    Humidity = (minHumidity + rand.NextDouble() * 20).ToString(),
                    RecordedTime = DateTime.UtcNow
                });

                Thread.Sleep(100);
            }

            simulator.Send(temparatureLists);

            Console.WriteLine("Inserting data for Device to cloud is completed.!!!");
        }
    }
}
