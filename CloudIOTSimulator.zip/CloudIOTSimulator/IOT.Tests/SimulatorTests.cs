using IOT.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics.CodeAnalysis;
using Moq;

namespace IOT.Tests
{
    [TestClass]
    [ExcludeFromCodeCoverage]
    public class SimulatorTests
    {
        private Simulator testSubject;
        //MockRepository mockRepo;

        [TestInitialize]
        public void TestInitilize()
        {
            testSubject = new Simulator();
        }

        [TestMethod]
        public void TestMethod1()
        {
            Assert.IsTrue(true);
        }
    }
}
